import java.util.concurrent.Semaphore;

public class Main {
    private static void produce(int min, int max) {

        int k = (int) (Math.round(Math.random() * (max - min) + min) * 500 );
        for ( int i = 0; i < k; i++) {
            i++;
            i--;
        }
    }

    public static void main(String[] args) {

        Semaphore semaphore = new Semaphore(2);

        Runnable thread1 = () -> {
            try {

                System.out.println("Thread-1 has started");

                while(true) {
                    System.out.println("Thread-1 - P0");

                    System.out.println("Thread-1 need semaphore");
                    semaphore.acquire(1);

                    System.out.println("Thread-1 - P1");
                    Main.produce(4_000,7_000);

                    semaphore.release(1);
                    System.out.println("Thread-1 - P2");

                    Thread.sleep(3_000);
                    System.out.println("Thread-1 - P3");
                }

            } catch(Exception e) {
                System.out.println(e.getMessage());
            }
        };

        Runnable thread2 = () -> {

            try {

                System.out.println("Thread-2 has started");

                while(true) {
                    System.out.println("Thread-2 - P4");

                    System.out.println("Thread-2 need semaphore");
                    semaphore.acquire(1);

                    System.out.println("Thread-2 - P5");
                    Main.produce(5_000,7_000);

                    semaphore.release(1);

                    System.out.println("Thread-2 - P6");

                    Thread.sleep(6_000);
                    System.out.println("Thread-2 - P7");

                }

            } catch(Exception e) {
                System.out.println(e.getMessage());

            }
        };

        Runnable thread3 = () -> {
            try{
                System.out.println("Thread-3 has started");

                while(true) {
                    System.out.println("Thread-3 - P17");

                    System.out.println("Thread-3 need semaphore");
                    semaphore.acquire(1);

                    System.out.println("Thread-3 - P18");
                    Main.produce(3_000,6_000);

                    semaphore.release(1);

                    Thread.sleep(5_000);
                    System.out.println("Thread-3 - P20");
                }

            } catch(Exception e) {
                System.out.println(e.getMessage());
            }
        };

        Thread t1 = new Thread(thread1, "Thread-1");
        Thread t2 = new Thread(thread2, "Thread-2");
        Thread t3 = new Thread(thread3, "Thread-3");

        t1.start();
        t2.start();
        t3.start();
    }
}