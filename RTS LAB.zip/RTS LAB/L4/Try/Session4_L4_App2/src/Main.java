import java.util.concurrent.locks.ReentrantLock;

public class Main {

    private static final ReentrantLock lock1 = new ReentrantLock();
    private static final ReentrantLock lock2 = new ReentrantLock();

    private static void produce(int min, int max) {
        int k = (int)(Math.round(Math.random() * (max - min) + min) * 500);
        for( int i = 0 ; i < k ; i ++) {
            i++;
            i--;
        }
    }

    public static void main(String[] args) {

        Runnable thread1 = () -> {
            try {
                System.out.println("Thread-1 has started");

                System.out.println("Thread-1 - P1");
                Main.produce(2,4);

                System.out.println("Thread-1 need lock1");
                lock1.lock();

                System.out.println("Thread-1 - P4");
                Main.produce(4,6);

                System.out.println("Thread-1 need lock2");
                lock1.unlock(); // moved here to avoid deadlock
                lock2.lock();

                System.out.println("Thread-1 - P6");
                Thread.sleep(4_000);


                lock2.unlock();
                System.out.println("Thread-1 - P7");

                System.out.println("Thread-1 finished");

            } catch(Exception e) {
                System.out.println(e.getMessage());
            }
        };

        Runnable thread2 = () -> {
            try {
                System.out.println("Thread-2 has started");

                System.out.println("Thread-2 - P2");
                Main.produce(3,5);

                System.out.println("Thread-2 need lock2");
                lock2.lock();

                System.out.println("Thread-2 - P3");
                Main.produce(5,7);

                System.out.println("Thread-2 need lock1");
                lock1.lock();

                System.out.println("Thread-2 - P5");

                Thread.sleep(5_000);
                lock1.unlock();
                lock2.unlock();

                System.out.println("Thread-2 - P8");
                System.out.println("Thread-2 finished");

            } catch(Exception e) {
                System.out.println(e.getMessage());
            }
        };

        Thread t1 = new Thread(thread1,"Thread-1");
        Thread t2 = new Thread(thread2, "Thread-2");

        t1.start();
        t2.start();
    }
}