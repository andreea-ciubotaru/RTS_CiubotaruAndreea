import java.util.*;

public class Main {

        public static void main(String[] args) {

            Random random = new Random();
            int[] array = new int[10];

            for (int i = 0; i < 10; i++) {
                int random_nr = random.nextInt(100);
                array[i] = random_nr;
            }

            System.out.println("The unsorted array of random randoms is:");
            for (int i = 0; i < 10; i++) {
                System.out.println(array[i]);
            }

            System.out.println("The sorted array of random randoms is:");
            Arrays.sort(array);
            for (int i = 0; i < 10; i++) {
                System.out.println(array[i]);
            }

        }

    }

