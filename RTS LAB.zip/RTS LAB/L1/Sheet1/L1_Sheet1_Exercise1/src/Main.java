import java.util.Scanner;

public class Main {
    public static void menu()
    {
        System.out.println("Please select one option from the menu:");
        System.out.println("\n 1. Add 2 complex numbers");
        System.out.println("\n 2. Subtract 2 complex numbers");
        System.out.println(("\n 3. Multiply 2 complex numbers"));

    }
    public static void main(String[] args) {

        menu();
        int choice;
        Scanner scanner = new Scanner(System.in);
        choice = scanner.nextInt();
        System.out.println("You choose option:");
        System.out.println(choice);

        switch(choice)
        {
            case 1: {
                System.out.println("\nPlease enter 2 complex numbers!");
                int real1;
                int img1;
                int real2;
                int img2;
                System.out.println("\n Please enter the real part of the first number:");
                real1 = scanner.nextInt();
                System.out.println("\n Please enter the imaginary part of the first number:");
                img1 = scanner.nextInt();
                System.out.println("\n Please enter the real part of the second number:");
                real2 = scanner.nextInt();
                System.out.println("\n Please enter the imaginary part of the second number:");
                img2 = scanner.nextInt();

                System.out.println("\n Perfect! You chose the numbers:");
                System.out.println(real1+ "+" + img1 + "i");
                System.out.println(real2+ "+" + img2 + "i");

                System.out.println("The addition of the 2 numbers you entered:");
                int real = real1 + real2;
                int img = img1 +img2;
                System.out.println(real+ "+" + img + "i");

                break;
            }

            case 2: {
                System.out.println("\nPlease enter 2 complex numbers!");
                int real1;
                int img1;
                int real2;
                int img2;
                System.out.println("\n Please enter the real part of the first number:");
                real1 = scanner.nextInt();
                System.out.println("\n Please enter the imaginary part of the first number:");
                img1 = scanner.nextInt();
                System.out.println("\n Please enter the real part of the second number:");
                real2 = scanner.nextInt();
                System.out.println("\n Please enter the imaginary part of the second number:");
                img2 = scanner.nextInt();

                System.out.println("\n Perfect! You chose the numbers:");
                System.out.println(real1 + "+" + img1 + "i");
                System.out.println(real2 + "+" + img2 + "i");

                System.out.println("The substaction of the 2 numbers you entered:");
                int real = real1 - real2;
                int img = img1 - img2;
                if (img > 0) {
                    System.out.println(real + "+" + img + "i");
                } else {
                    System.out.println(real + "" + img + "i");
                }

                break;
            }

            case 3:
            {
                System.out.println("\nPlease enter 2 complex numbers!");
                int real1;
                int img1;
                int real2;
                int img2;
                System.out.println("\n Please enter the real part of the first number:");
                real1 = scanner.nextInt();
                System.out.println("\n Please enter the imaginary part of the first number:");
                img1 = scanner.nextInt();
                System.out.println("\n Please enter the real part of the second number:");
                real2 = scanner.nextInt();
                System.out.println("\n Please enter the imaginary part of the second number:");
                img2 = scanner.nextInt();

                System.out.println("\n Perfect! You chose the numbers:");
                System.out.println(real1 + "+" + img1 + "i");
                System.out.println(real2 + "+" + img2 + "i");

                System.out.println("The multiplication of the 2 numbers you entered:");
                int real = real1*real2 + img1*img2*(-1);
                int img = real1*img2 + img2*real2;

                if (img > 0) {
                    System.out.println(real + "+" + img + "i");
                } else {
                    System.out.println(real + "" + img + "i");
                }

                break;
            }

            default: {
                System.out.println("There is no such option!");
            }
        }
    }
}