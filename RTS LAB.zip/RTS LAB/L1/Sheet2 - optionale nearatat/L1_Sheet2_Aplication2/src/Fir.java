import java.util.*;

//Model
public class Fir extends Observable implements Runnable {

    private int id;
    private Window win;
    int processorLoad;

    Thread thread;

    public int c = 0;

    public void start(int priority)
    {
        if(thread == null)
        {
            thread = new Thread(this);
            thread.start();
            thread.setPriority(priority);
        }
    }

    Fir(int id,  Window win, int procLoad) {
        this.id = id;
        this.win = win;
        this.processorLoad = procLoad;
        //this.setPriority(priority);
    }
        public void run()
        {
            while (c < 1000) {
                for (int j = 0; j < this.processorLoad; j++) {
                    j++;
                    j--;

                    this.setChanged();
                    this.notifyObservers();
                }
                c++;
                this.win.setProgressValue(id, c);
            }
        }

    public int getId() {
        return id;
    }

    public int getC() {
        return c;
    }
}
