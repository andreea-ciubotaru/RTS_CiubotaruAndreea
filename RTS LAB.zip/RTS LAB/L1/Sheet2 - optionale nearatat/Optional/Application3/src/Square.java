public class Square {
    int x, y, size, speed;

    public Square(int x, int y, int size, int speed) {
        this.x = x;
        this.y = y;
        this.size = size;
        this.speed = speed;
    }
}

