import javax.swing.*;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

public class TankGame extends JFrame {
    private GamePanel gamePanel;
    private AtomicBoolean running = new AtomicBoolean(false);
    private AtomicInteger score = new AtomicInteger(0);
    private AtomicInteger resumesLeft = new AtomicInteger(3);

    public TankGame() {
        setTitle("Tank Game with Shooting");
        setSize(GamePanel.WINDOW_WIDTH, GamePanel.WINDOW_HEIGHT);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);

        gamePanel = new GamePanel(running, score, resumesLeft);
        add(gamePanel);
        addKeyListener(new TankController(gamePanel));

        setVisible(true);
        gamePanel.resetGame();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(TankGame::new);
    }
}
