import java.awt.Rectangle;

public class GameObject extends Rectangle {
    // Properties specific to game objects, e.g., velocity for squares and shells

    public GameObject(int x, int y, int width, int height) {
        super(x, y, width, height);
        // Initialize properties
    }

    // Methods for behavior, e.g., move for squares and shells
}
