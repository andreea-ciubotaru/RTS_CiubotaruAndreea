import javax.swing.*;
import java.awt.*;
import java.util.Random;

public class Main extends JFrame {
    private static final int WINDOW_WIDTH = 400;
    private static final int WINDOW_HEIGHT = 400;
    private static final int SQUARE_SIZE = 50;
    private static final int MIN_SPEED = 5;
    private static final int MAX_SPEED = 10;
    private static final int GAME_ROUNDS = 3;

    private static final SquarePanel panel = new SquarePanel();

    private Main() {
        this.setSize(WINDOW_WIDTH, WINDOW_HEIGHT);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.add(panel);
        this.setVisible(true);
    }

    private static void startGame() {

        Thread gameThread = new Thread(new Runnable() {
            @Override
            public void run() {

                for (int round = 0; round < GAME_ROUNDS; round++) {

                    panel.startRound();

                    while (!panel.roundFinished()) {

                        panel.moveSquares();
                        try {
                            Thread.sleep(100);
                        } catch (InterruptedException e) {
                            Thread.currentThread().interrupt();
                        }
                    }
                    panel.resetRound();
                }
            }
        });

        gameThread.start();
    }


    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            Main game = new Main();
            game.startGame();
        });
    }

    private static class SquarePanel extends JPanel {
        private Square[] squares = new Square[3];

        public void startRound() {
            for (int i = 0; i < squares.length; i++) {
                int speed = new Random().nextInt(MAX_SPEED - MIN_SPEED + 1) + MIN_SPEED;
                squares[i] = new Square(i * SQUARE_SIZE * 2 + SQUARE_SIZE, 0, SQUARE_SIZE, speed);
            }
        }

        public boolean roundFinished() {
            for (Square square : squares) {
                if (square.y < WINDOW_HEIGHT - square.size) {
                    return false;
                }
            }
            return true;
        }

        public void moveSquares() {
            for (Square square : squares) {
                square.y += square.speed;
            }
            repaint();
        }

        public void resetRound() {
            for (Square square : squares) {
                square.y = 0;
            }
            repaint();
            try {
                Thread.sleep(2000); // Wait a bit before starting the next round
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            for (Square square : squares) {
                g.fillRect(square.x, square.y, square.size, square.size);
            }
        }

        static class Square {
            int x, y, size, speed;

            Square(int x, int y, int size, int speed) {
                this.x = x;
                this.y = y;
                this.size = size;
                this.speed = speed;
            }
        }
    }
}
